<?php
// Text
$_['text_title']       = 'Paczkomaty';
$_['text_description'] = 'Paczkomaty (%s) - Wybierz paczkomat %s';