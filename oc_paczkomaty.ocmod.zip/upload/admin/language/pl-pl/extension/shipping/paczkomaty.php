<?php
// Heading
$_['heading_title']    = 'Paczkomaty inPost';

// Text
$_['text_shipping']    = 'Wysyłka';
$_['text_success']     = 'Sukces: Zmiany zostały zapisane!';
$_['text_edit']        = 'Edycja wysyłki Stała stawka';

// Entry
$_['entry_cost']       = 'Koszt';
$_['entry_tax_class']  = 'Klasa podatków';
$_['entry_geo_zone']   = 'Strefa geograficzna';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Kolejność wyświetlania';

// Error
$_['error_permission']      = 'Uwaga: Nie masz uprawnień do tego działu!';